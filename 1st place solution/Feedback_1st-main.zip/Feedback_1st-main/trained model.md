## Copy of model weights
We uploaded all the model weights to kaggle datasets:  
pca/lstm/lgb model:  https://www.kaggle.com/datasets/whitebird/fdddw3  
bert model:  
https://www.kaggle.com/datasets/wht1996/bart-large-finetuned-squadv1  
https://www.kaggle.com/datasets/piupiupiu/model-fold5
https://www.kaggle.com/datasets/piupiupiu/distilbart-xsum-12-6-fold5
https://www.kaggle.com/datasets/wht1996/distilbart-mnli-12-9-adv-cv6
https://www.kaggle.com/datasets/piupiupiu/distilbart-cnn-12-6-fold5
https://www.kaggle.com/datasets/piupiupiu/deberta-v2-xlarge-real-fold5
https://www.kaggle.com/datasets/piupiupiu/deberta-v2-xlarge-adv-fold5
https://www.kaggle.com/datasets/wht1996/feedback-0130